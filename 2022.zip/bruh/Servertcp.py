import socket
import sys

host = '192.168.0.4'
data_payload = 2048
backlog = 1
port = 9900

def echo_server(port):
    """A simple echo server"""
    # Create a TCP socket
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    # Enable reuse address/port
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    # Bind the socket to the port
    server_address = (host, port)
    print("Starting up echo server on %s port %s" % server_address)
    try:
        sock.bind(server_address)
    except Exception as e:
        print("Error binding the socket:", str(e))
        sys.exit(1)

    # Listen to clients, backlog argument specifies the maximum number of queued connections
    sock.listen(backlog)
    print("Waiting for messages from client")

    client, address = sock.accept()

    while True:
        data = client.recv(9000).decode('utf-8')
        print("Message from client: %s" % data)
        message = input("server: ")
        print("Sending %s" % message)
        client.sendall(message.encode('utf-8'))

        # End connection
        if data == 'exit':
            print("Disconnecting from the client")
            client.close()
            break

    sock.close()

if _name_ == '_main_':
    port = 9900
    echo_server(port)
