import socket
import sys

host = '192.168.0.11'
data_payload = 2048

def echo_client(port):
    """A simple echo client"""
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    server_address = (host, port)
    print("Connecting to %s port %s" % server_address)
    message = "Test message. This will be echoed"
    try:
        # Send data
        print("Sending %s" % message)
        sent = sock.sendto(message.encode('utf-8'), server_address)

        # Receive response
        data, server = sock.recvfrom(data_payload)
        print("Received %s" % data.decode())
    finally:
        print("Closing connection to the server")
        sock.close()

if __name__ == "__main__":
    echo_client(9900)
