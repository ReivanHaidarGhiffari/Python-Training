import socket
import sys

def echo_client(port):
    """A simple echo client"""
    # Create a TCP/IP socket
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    # Connect the socket to the server
    server_address = ('localhost', port)
    print("Connecting to %s port %s" % server_address)
    try:
        sock.connect(server_address)
    except Exception as e:
        print("Connection error:", str(e))
        sys.exit(1)

    while True:
        # Send data
        message = input("client: ")
        print("Sending %s" % message)
        sock.sendall(message.encode('utf-8'))

        # Look for the response
        data = sock.recv(9000).decode('utf-8')
        print("Received: %s" % data)

        if data == 'exit':
            print("Koneksi dari server terputus")
            sock.close()
            break

if __name__ == '__main__':
    port = 9900
    echo_client(port)