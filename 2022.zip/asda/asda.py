import pandas as pd
from keras.models import Sequential
from keras.layers import Dense

dataset = pd.read_csv('daftar_mahasiswa.csv')

x = dataset.iloc[:, 1:].values
y = dataset.iloc[:, 0].values

model = Sequential()
model.add(Dense(1, input_dim=3, activation='sigmoid'))

model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])

model.fit(x, y, epochs=100, batch_size=2, verbose=0)

input_data = [[22, 3, 0]]
prediction = model.predict(input_data)

if prediction > 0.5:
    gender = 'MALE'
else:
    gender = 'FEMALE'

print("Prediction for [22, 3, 0, 4]:", gender)

model.fit(x, y, epochs=100, batch_size=2, verbose=0)
prediction = model.predict(input_data)

if prediction > 0.5:
    gender = 'MALE'
else:
    gender = 'FEMALE'

print("Prediction for [22, 3, 0, 4] (after 100 epochs):", gender)
