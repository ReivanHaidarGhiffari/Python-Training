import socket
import sys

print("\nAplikasi Chatting Post Test NRP Genap\n")
print("Reivan Haidar Ghiffari 2421600012\n")


hostname = socket.gethostname()
ip = socket.gethostbyname(hostname)
print(hostname, "(", ip, ")")
port = 8765
print("Port :", port)


sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
try:
    sock.bind((ip, port))
    print("Menunggu Koneksi dulu")
except socket.error as e:
    print("Error:", e)
    sys.exit(1)

data_payload = 2048


def send_message(client_address, message):
    sock.sendto(message.encode('utf-8'), client_address)


def receive_message():
    data, address = sock.recvfrom(data_payload)
    return data.decode(), address


while True:
    data, address = receive_message()
    print("Tersambung Ke : ", address)

    while True:
        if data == "[e]":
            message = "Selamat datang"
            send_message(address, message)
            print("\n")
            break
        print(f"Client: {data}")
        message = input("Server: ")
        send_message(address, message)
        data, address = receive_message()

    print("Memutus Koneksi")

sock.close()
