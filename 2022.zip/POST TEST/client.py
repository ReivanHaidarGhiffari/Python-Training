import socket
import os
import socketserver

print("Client")
print("\nReivan Haidar Ghiffari 2421600012")

class clientudp:
    def __init__(self):
        self.data_payload = 2048
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.history_file = None

    def host_info(self):
        self.host = socket.gethostname()
        self.ip = socket.gethostbyname(self.host)
        print(self.host, "(", self.ip, ")\n")

    def isimenu(self):
        while True:
            print("Menu Pilihan:")
            print("1. Aplikasi Chatting")
            print("2. Melihat percakapan sebelumnya")
            print("3. Hapus history")
            menus = int(input("Pilihan Menu :  "))

            if menus == 1:
                self.connect_to_server()
            elif menus == 2:
                file = str(input("Nama Filenya: "))
                self.history_file = f"{file}.txt"
                with open(self.history_file, "r") as history:
                    print("Isi Chat:")
                    print(history.read())
            elif menus == 3:
                file = str(input("Nama File yang ingin dihapus: "))
                self.history_file = f"{file}.txt"
                try:
                    os.remove(self.history_file)
                    print("File chat berhasil dimusnahkan\n")
                except FileNotFoundError:
                    print("Tidak ada file bernama tersebut.")
            else:
                print("Pilihan 1-3.")
                socketserver.close()  # Mengulang loop jika pilihan tidak valid

    def connect_to_server(self):
        hostname = socket.gethostname()
        ip = socket.gethostbyname(hostname)
        server_ip = str(input("IP: "))
        server_port = int(input("Port: "))
        server = (server_ip, server_port)
        # Send a hello message to the server
        print("Tersambung Koneksi")
        print("\nSelamat datang dalam aplikasi chatting")
        print("Anda mengakses server :", hostname, "dengan IP 192.168.2.100 dari komputer ", hostname, "Dengan IP ", ip )
        self.history_file = f"{server_ip}.txt"
        history = open(self.history_file, "a")
        try:
            while True:
                message = str(input("Client: "))
                if message in {"Quit", "quit"}:
                    history.close()
                    print("Menyimpan data pada file txt\n")
                    break
                else:
                    history.write("Client: %s\n" % message)
                    self.sock.sendto(message.encode('utf-8'), server)
                    data, _ = self.sock.recvfrom(self.data_payload)
                    if message == "[e]":
                        message = "Keluar tanpa menyimpan data"
                        break

                    data = data.decode()
                    print("Server:", data)
                    history.write("Server: %s\n" % data)
        finally:
            print("Tutup Koneksi :")
            self.sock.close()

chat_client = clientudp()
chat_client.host_info()
chat_client.isimenu()
