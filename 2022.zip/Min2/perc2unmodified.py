print("PPPN")
n = int(input("\nMasukan Jumlah Bilangan = "))
bil = []
tot = 0
for x in range(n):
     m=x+1
     a = int(input("Bilangan ke %d = "%m))
     bil.append(a)
     tot += bil[x]
     rata2 = tot/n

print("\nBilangan Terkecil : %d " %min(bil))
print("\nBilangan Terbesar : %d " %max(bil))
print("Nilai Rata-Rata : %0.2f" %rata2)
