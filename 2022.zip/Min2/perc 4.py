def total_pembelian():
    tot = 0
    x = int(input("Jumlah Barang Yang Dibeli : "))
    for i in range (x):
        barang = input("\nNama Barang : " )
        harga = int(input("Harga Barang : "))
        jumlah = int(input("Jumlah Barang : "))
        tot += harga*jumlah

    print("\nTotal : ", tot)

total_pembelian()
