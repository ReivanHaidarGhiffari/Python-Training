import math

def menu ():
    print ("menu")
    print ("--------------------------------------------")
    print ("1, LuasPersegi")
    print ("2. LuasPersegiPanjang")
    print ("3. LuasSegitiga")
    print ("4. LuasLingkaran")
    print ("5. LuasJajarGenjang")
    print ("6. Keluar")

def LuasPersegi():
    print('Program Mencari Luas Persegi')
    print('-----------------------------------------')
    x = float(input('Panjang sisi : '))
    Luas = x * x
    print(' ')
    print('Luas perseginya adalah : ', Luas,'cm2')
    print(' ')
    print ("Mau Coba Lagi [Y/N]?")
    back = input().upper()
    if back == "Y":
        menu()
        
    else:
        exit()

def LuasPersegiPanjang():
    print('Program Mencari Luas Persegi Panjang')
    print('-----------------------------------------')
    P = float(input('Masukan Panjang : '))
    print(' ' )
    L = float(input('Masukan Lebar : '))
    Luas = P*L
    print(' ' )
    print('Luas persegi panjangnya adalah : ',Luas,'cm2')
    print(' ' )
    print ("Mau Coba Lagi [Y/N]?")
    back = input().upper()
    if back == "Y":
        menu()
    else:
        exit()

def LuasSegitiga():
    print('Program Mencari Luas Persegi Panjang')
    print('-----------------------------------------')
    A = float(input('Masukan Alas : '))
    print(' ' )
    T = float(input('Masukan Tinggi : '))
    Luas = 0.5 *A *T
    print(' ' )
    print('Luas segitiganya adalah : ',Luas,'cm2')
    print(' ' )
    print ("Mau Coba Lagi [Y/N]?")
    back = input().upper()
    if back == "Y":
        menu()
    else:
        exit()

def LuasLingkaran():
    print('Program Mencari Luas Persegi')
    print('-----------------------------------------')
    r = float(input('Masukan Radius : '))
    Luas = math.pi*r**2
    print(' ' )
    print('Luas perseginya adalah : ',Luas,'cm2')
    print(' ' )
    print ("Mau Coba Lagi [Y/N]?")
    back = raw_input().upper()
    if back == "Y":
        menu()
    else:
        exit()

def LuasJajarGenjang():
    print('Program Mencari Luas Persegi Panjang')
    print('-----------------------------------------')
    A = float(input('Masukan Alas : '))
    print(' ' )
    T = float(input('Masukan Tinggi : '))
    Luas = A*T
    print(' ' )
    print('Luas persegi panjangnya adalah : ',Luas,'cm2')
    print(' ' )
    print ("Mau Coba Lagi [Y/N]?")
    back = input().upper()
    if back == "Y":
        menu()
    else:
        exit()

while True:
    menu()
    pilih = int(input("Pilih Bangun Ruang (1-5) : "))
    if pilih == 1:
        LuasPersegi()
    elif pilih == 2:
        LuasPersegiPanjang()
    elif pilih == 3:
        LuasSegitiga()
    elif pilih == 4:
        LuasLingkaran()
    elif pilih == 5:
        LuasJajarGenjang()
    elif pilihan == 6:
        exit()






