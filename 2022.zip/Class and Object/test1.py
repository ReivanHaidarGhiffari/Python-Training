class Myclass:
    x=5

print(Myclass)
