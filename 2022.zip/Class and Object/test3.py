class Orang:
    def _init_ (self, nama, usia):
        self.nama = nama
        self.usia = usia

def myfunc(self):
    print("Hello Namaku" + self.nama)

p1 = Orang("John",36)
p1.myfunc()


        
