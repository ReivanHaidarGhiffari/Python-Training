class Myclass:
    x=5
    y=2

p1 = Myclass()
print(p1.x)
print(p1.y)

