import os
import socket
import threading
import socketserver

SERVER_PORT = 9999
BUFF_SIZE = 1024

class ThreadedTCPRequestHandler(socketserver.BaseRequestHandler):
    def handle(self):
        try:
            data = self.request.recv(1024)
            cur_thread = threading.current_thread()
            response = "%s: %s" %(cur_thread.name, data)
            print(response)
            message = input ("Server : ")
            self.request.sendall(message.encode('utf-8'))
        except Exception as e:
            print("Other exception: %s" %str(e))
class ThreadedTCPServer(socketserver.ThreadingMixIn,socketserver.TCPServer):
    pass
if __name__ == "__main__":
    port = int(input("Masukkan Port Server: "))
    server = ThreadedTCPServer(("", port),ThreadedTCPRequestHandler)
    ip, port = server.server_address
    
    server_thread = threading.Thread(target=server.serve_forever)
    server_thread.start()
    print("Server loop running on thread: %s" %server_thread.name)
