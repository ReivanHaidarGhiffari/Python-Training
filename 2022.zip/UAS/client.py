import argparse
import socket
import sys
import time

SERVER_HOST = str(input("Masukkan IP Server : "))
SERVER_PORT = 9999
BUFFER_SIZE = 1024

def echo_client(host, port):
    """A simple echo client"""
    t = 1
    while 1:
        # Send data
        while True:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            # Connect the socket to the server
            server_address = (host, port)
            sock.settimeout(10)
            try:
                sock.connect(server_address)
                # Send data
                message = input("Client: ")
                sock.sendall(message.encode('utf-8'))

                # Look for the response
                amount_received = 0
                amount_expected = len(message)
                while amount_received < amount_expected:
                    data = sock.recv(16)
                    amount_received += len(data)
                    print("Msg dari server: %s" % data.decode())

                    sock.close()
            except socket.error as e:
                sock.close()
                if t > 3:
                    print(e)
                    break
                else:
                    t = t + 1
                    time.sleep(1)
                    
port = int(input("Masukkan Port Server: "))
echo_client(SERVER_HOST, port)
