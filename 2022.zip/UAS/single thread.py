import time

print("Reivan Haidar Ghiffari 2421600012\n")

def print_time (proses, delay):
    count = 0
    while count < 5:
        time.sleep(delay)
        count += 1
        print ("%s: %s" % (proses, time.ctime(time.time())))

print_time ("Proses-1", 3)
print_time ("Proses-2", 4)
print_time ("Proses-3", 5)
