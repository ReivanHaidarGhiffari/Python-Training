import argparse
import socket
import sys
import time
import ipaddress

SERVER_PORT = 9999
BUFF_SIZE = 1024

def echo_client(host, port):
    t = 1
    while True:
        # Send data
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_address = (str(host), port)
        sock.settimeout(10)
        try:
            sock.connect(server_address)
            message = input("Client: ")
            sock.sendall(message.encode('utf-8'))
            
            data = sock.recv(16)
            print("Msg dari server: %s" % data.decode())
            
            sock.close()
        except socket.error as e:
            sock.close()
            if t > 3:
                print(e)
                break
            else:
                t = t + 1
                time.sleep(1)
if __name__ == "__main__":
    host = input("Masukkan Server Host: ")
    try:
        ipaddress.ip_address(host)
    except ValueError:
        print("IP yang dimasukkan tidak valid")
        sys.exit(1)
        
    port = int(input("Masukkan Port Server: "))
    echo_client(host, port)
