print ("Selamat datang di program Biodata")
print ("=================================")

nama = input("Nama : ")
umur = input("Umur: ")
alamat = input("Alamat: ")

teks = "Nama: {}\nUmur: {}\nAlamat: {}".format(nama, umur, alamat)

file_bio = open("Biodata.txt", "a")

file_bio.write(teks)

file_bio.close()
