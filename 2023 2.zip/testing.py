import random

class Node:
    def __init__(self, label, x, y):
        self.label = label
        self.x = x
        self.y = y

def generate_random_nodes(num_nodes):
    nodes = []
    for i in range(1, num_nodes + 1):
        x = random.randint(1, 9)
        y = random.randint(1, 9)
        node = Node(str(i), x, y)
        nodes.append(node)
    return nodes

def print_nodes(nodes):
    for i, node in enumerate(nodes, start=1):
        print(f'nodes({i}) = node("{node.label}", {node.x}, {node.y});')

# Example: Generate and print nodes for numbers 1 to 100
num_nodes = 100
random_nodes = generate_random_nodes(num_nodes)
print_nodes(random_nodes)
